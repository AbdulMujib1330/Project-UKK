<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tanggapan</title>
  <!-- <=======Bootstrap=======> -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.3/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.5/css/buttons.dataTables.min.css">
  <!-- Icon -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!-- ---- -->
  <!-- Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Kanit&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Kanit&family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,300&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
  <!-- ---- -->
  <!-- <link rel="stylesheet" href="layout.css"> -->
  <!-- <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> -->
</head>
<style>
  /* <====Layout?====> */
  html {
    height: 100vh;
  }

  body {
    margin: 0;
    padding: 0;
  }

  .div {
    display: flex;
  }

  nav,
  main,
  aside,
  footer {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  nav {
    position: fixed;
    width: 100%;
    height: 9vh;
    background: #02231c;
    z-index: 3;
  }

  main {
    width: 100%;
    height: 100vh;
    background: white;
    z-index: 1;
  }

  aside {
    width: 240px;
    height: 100vh;
    background: rgb(30, 30, 30);
    z-index: 2;
    padding-right: 10px;
    padding-left: 10px;
    display: block;
  }

  /* <--- Navbar ---> */
  nav {
    display: block;
    margin: 0;
    padding: 0;
  }

  .ul {
    list-style-type: none;
    display: flex;
    margin: 0;
    padding: 0;
  }

  .li {
    text-align: center;
    width: 100px;
    cursor: pointer;

  }

  .a {
    color: white;
    text-decoration: none;
    font-family: 'poppins', sans-serif;
    font-weight: 400;
    line-height: 9vh;
    cursor: pointer;
  }

  .menu2 {
    text-align: center;
    width: 100px;
    cursor: pointer;
    margin-left: auto;
    background-color: #307107;
  }

  .btn-menu {
    color: white;
    /* text-decoration: none;
        font-family: 'poppins', sans-serif;
        font-weight: 400; */
    line-height: 9vh;
    cursor: pointer;
    font-size: 35px;
  }

  .display-mini {
    display: none;
    padding: 0;
    margin: 0;
  }

  .profile-bottom {
    display: none;
  }

  .item-nav {
    padding: 0;
    margin: 0;
  }

  .open .item {
    display: none;
  }

  .open .display-mini {
    display: block;
    background-color: black;
    margin: 0;
    list-style-type: none;
  }

  .open .profile-bottom {
    display: block;
    margin: 0;
    list-style-type: none;
    padding: 0;
  }

  .open .li-items:hover {
    background-color: #111011;
    transition: all 0.2s;
  }

  .open .profile:hover {
    background-color: #010529;
  }

  /* .li-items-dropdown:hover {
    background-color: red;
  } */
  .button {
    display: contents;
  }

  .dropdown-toggle::after {
    margin-left: auto;
    vertical-align: middle;
    line-height: 50px;
    margin-right: 5%;
  }

  .dropdown-toggle {
    margin-left: auto;
  }

  .drop-items {

    color: black;
    display: block;
    font-family: 'poppins', sans-serif;
    font-size: 18px;
    font-weight: 400;
    text-decoration: none;
    display: block;
    text-align: start;
  }

  .button {
    width: 100%;
    background: #000;
    /* background-color: #f1f1f1; */
  }

  .show.red {
    background-color: red;
  }

  .show {
    margin-bottom: 258px;
  }

  .center {
    display: flex;
    align-items: center;
    text-align: center;
  }

  .dropdown-menu {
    width: 100%;
    margin-top: 50px;
    border-radius: 0px;
    margin-bottom: 0px;
    padding-bottom: 0px;
    border: 0px;
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 100%;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    margin-top: 150px;
    z-index: 1;
  }

  .modal-backdrop {
    z-index: 0;
    opacity: 0;
  }

  .modal-backdrop.show {
    /* z-index: 0; */
    opacity: 0;
  }

  /* .dropdown1,
  .dropbtn {
    color: black;
    text-align: center;
    text-decoration: none;
  }

  .dropdown1 .drop-items:hover,
  .dropdown1:hover .dropbtn {
    background-color: red;
  } */



  /* .position:hover {
    margin-bottom: 250px;
  }

  .dropdown-content .dropdown1 {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }

  .dropdown-content .drop-items:hover {
    background-color: #f1f1f1;
  }

  .dropdown1:hover .dropdown-content {
    display: block; */
  }

  .left-auto {
    line-height: 50px;
    font-size: 25px;
    color: white;
    min-width: 100px;
    height: 50px;
    text-align: center;
    margin-left: auto;
  }

  .icon-drop {
    line-height: 50px;
    font-size: 25px;
    color: black;
    min-width: 80px;
    height: 50px;
    text-align: center;
  }

  .drop-bottom .dropdown1:hover {
    margin-top: 250px;
  }

  .drop-items:hover {
    background-color: #f1f1f1;
  }

  @media screen and (min-width : 768px) {
    .menu2 {
      display: none;
    }

    .item-nav {
      display: none;
    }

    /* 
        .display-mini {
            display: none;
        }

        .profile-bottom {
            display: none;
        } */
  }

  @media screen and (max-width : 425px) {

    /* .item-nav{
        display: none;
      } */
    .item {
      display: none;
    }

    /* .display-mini {
            display: none;
        }

        .profile-bottom {
            display: none;
        }

        .item {
            display: none;
        } */
  }

  @media screen and (max-width : 768px) {

    .item {
      display: none;
    }

  }

  /* @media screen and (max-width : 768px) {
        .display-mini{
            display: none;
        }
        .profile-bottom{
            display: none;
        }
    } */















  /* <--- Asidebar ---> */
  @media screen and (max-width : 1125px) {
    aside {
      display: none;
    }
  }

  @media screen and (max-height : 672px) {
    ul.display {
      /* list-style-type: none; */
      /* padding-top: 80px; */
      /* padding-left: 0; */
      /* margin: 0; */
      /* display: block; */
      height: 80%;
    }

    ul.bottom {
      /* list-style-type: none; */
      /* padding-left: 0; */
      /* margin: 0; */
      /* display: block; */
      padding-top: 50px;
      /* height: auto; */
    }
  }

  aside.mini {
    width: 42px;
    transition: all 0.5s;
  }

  aside.mini {
    width: 100px;
    transition: all 0.5s;
  }

  aside {
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    width: 240px;
    background: #11101d;
    transition: all 0.5s ease;
  }

  /* aside ul{
    list-style-type: none;
    padding-top: 80px;
    padding-left: 0;
    margin: 0;
    display: block;
    height: 100%;
} */
  .display {
    list-style-type: none;
    padding-top: 80px;
    padding-left: 0;
    margin: 0;
    display: block;
    height: 92%;
  }

  .li-button {
    border-bottom: white solid 1px;
    cursor: pointer;
    text-align: center;
  }

  .cursor {
    cursor: pointer;
    color: white;
    font-size: 35px;
  }

  .li-items {
    box-sizing: border-box;
    height: 50px;
    align-items: center;
    cursor: pointer;
  }

  .position {
    display: flex;
    align-items: center;
    text-decoration: none;
    cursor: pointer;
  }

  .link {
    color: white;
    font-family: 'poppins', sans-serif;
    font-size: 18px;
    font-weight: 400;
    text-decoration: none;
  }

  .icon {
    line-height: 50px;
    font-size: 25px;
    color: white;
    min-width: 80px;
    height: 50px;
    text-align: center;
  }

  .icon-profile {
    line-height: 50px;
    font-size: 25px;
    color: white;
    min-width: 50px;
    height: 50px;
  }

  .profile {
    background-color: rgb(21, 27, 84);
    box-sizing: border-box;
    height: 50px;
    align-items: center;
    transition: all ease 0.5s;
    text-align: center;
  }

  .log {

    min-width: 80px;
    line-height: 50px;
    font-size: 25px;
    color: white;
    height: 50px;
    text-align: center;
  }

  .mini .profile {
    transition: all ease 0.5s;
    display: none;
  }

  .mini .link {
    transition: all 5s;
    display: none;
  }

  /* .mini .bxs-file-plus {
    display: none;
  } */

  .bottom {
    list-style-type: none;
    padding-left: 0;
    margin: 0;
    display: block;
    height: auto;
  }

  /* 
aside ul {
	width: 100%;
    padding: 0;
}

aside ul li {
	text-align: start;
	width: 100%;
	position: relative;
	background-color: green;
	display: block;
	line-height: 50px;
	justify-content: center;
	transition: all 0.5s;
}

aside ul li.li-items {
	padding-top: 10px;
}

aside ul li button {
	text-align: start;
	background-color: transparent;
	border: 0;
	font-size: 40px;
	width: 100%;
	padding: 0px;
}

aside ul li button i.bx {
	color: white;
	vertical-align: middle;
	margin: auto;
	padding-top: auto;
	padding-bottom: auto;
}

aside ul li a {
	color: white;
	font-size: 20px;
	text-decoration: none;
	font-family: "Roboto", sans-serif;
	text-align: center;
	vertical-align: middle;
}

aside ul li a i.bx {
	color: white;
	font-size: 30px;
	text-decoration: none;
} */
  /* ----- ANIMATION ------- */
  /*! UIkit 3.15.24 | https://www.getuikit.com | (c) 2014 - 2023 YOOtheme | MIT License */
  /* ========================================================================
   Component: Base
 ========================================================================== */
  /*
 * 1. Set `font-size` to support `rem` units
 * 2. Prevent adjustments of font size after orientation changes in iOS.
 * 3. Style
 */

  [class*='uk-animation-'] {
    animation: 0.5s ease-out both;
  }

  /* Animations
 ========================================================================== */
  /*
 * Fade
 */
  .uk-animation-fade {
    animation-name: uk-fade;
    animation-duration: 0.8s;
    animation-timing-function: linear;
  }

  /*
 * Scale
 */
  .uk-animation-scale-up {
    animation-name: uk-fade, uk-scale-up;
  }

  .uk-animation-scale-down {
    animation-name: uk-fade, uk-scale-down;
  }

  /*
 * Slide
 */
  .uk-animation-slide-top {
    animation-name: uk-fade, uk-slide-top;
  }

  .uk-animation-slide-bottom {
    animation-name: uk-fade, uk-slide-bottom;
  }

  .uk-animation-slide-left {
    animation-name: uk-fade, uk-slide-left;
  }

  .uk-animation-slide-right {
    animation-name: uk-fade, uk-slide-right;
  }

  /*
 * Slide Small
 */
  .uk-animation-slide-top-small {
    animation-name: uk-fade, uk-slide-top-small;
  }

  .uk-animation-slide-bottom-small {
    animation-name: uk-fade, uk-slide-bottom-small;
  }

  .uk-animation-slide-left-small {
    animation-name: uk-fade, uk-slide-left-small;
  }

  .uk-animation-slide-right-small {
    animation-name: uk-fade, uk-slide-right-small;
  }

  /*
 * Slide Medium
 */
  .uk-animation-slide-top-medium {
    animation-name: uk-fade, uk-slide-top-medium;
  }

  .uk-animation-slide-bottom-medium {
    animation-name: uk-fade, uk-slide-bottom-medium;
  }

  .uk-animation-slide-left-medium {
    animation-name: uk-fade, uk-slide-left-medium;
  }

  .uk-animation-slide-right-medium {
    animation-name: uk-fade, uk-slide-right-medium;
  }

  /*
 * Kenburns
 */
  .uk-animation-kenburns {
    animation-name: uk-kenburns;
    animation-duration: 15s;
  }

  /*
 * Shake
 */
  .uk-animation-shake {
    animation-name: uk-shake;
  }

  /*
 * SVG Stroke
 * The `--uk-animation-stroke` custom property contains the longest path length.
 * Set it manually or use `uk-svg="stroke-animation: true"` to set it automatically.
 * All strokes are animated by the same pace and doesn't end simultaneously.
 * To end simultaneously, `pathLength="1"` could be used, but it's not working in Safari yet.
 */
  .uk-animation-stroke {
    animation-name: uk-stroke;
    animation-duration: 2s;
    stroke-dasharray: var(--uk-animation-stroke);
  }

  /* Direction modifier
 ========================================================================== */
  .uk-animation-reverse {
    animation-direction: reverse;
    animation-timing-function: ease-in;
  }

  /* Duration modifier
 ========================================================================== */
  .uk-animation-fast {
    animation-duration: 0.1s;
  }

  /* Toggle animation based on the State of the Parent Element
 ========================================================================== */
  .uk-animation-toggle:not(:hover):not(:focus) [class*='uk-animation-'] {
    animation-name: none;
  }

  /* Keyframes used by animation classes
 ========================================================================== */
  /*
 * Fade
 */
  @keyframes uk-fade {
    0% {
      opacity: 0;
    }

    100% {
      opacity: 1;
    }
  }

  /*
 * Scale
 */
  @keyframes uk-scale-up {
    0% {
      transform: scale(0.9);
    }

    100% {
      transform: scale(1);
    }
  }

  @keyframes uk-scale-down {
    0% {
      transform: scale(1.1);
    }

    100% {
      transform: scale(1);
    }
  }

  /*
 * Slide
 */
  @keyframes uk-slide-top {
    0% {
      transform: translateY(-100%);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-bottom {
    0% {
      transform: translateY(100%);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-left {
    0% {
      transform: translateX(-100%);
    }

    100% {
      transform: translateX(0);
    }
  }

  @keyframes uk-slide-right {
    0% {
      transform: translateX(100%);
    }

    100% {
      transform: translateX(0);
    }
  }

  /*
 * Slide Small
 */
  @keyframes uk-slide-top-small {
    0% {
      transform: translateY(-10px);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-bottom-small {
    0% {
      transform: translateY(10px);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-left-small {
    0% {
      transform: translateX(-10px);
    }

    100% {
      transform: translateX(0);
    }
  }

  @keyframes uk-slide-right-small {
    0% {
      transform: translateX(10px);
    }

    100% {
      transform: translateX(0);
    }
  }

  /*
 * Slide Medium
 */
  @keyframes uk-slide-top-medium {
    0% {
      transform: translateY(-50px);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-bottom-medium {
    0% {
      transform: translateY(50px);
    }

    100% {
      transform: translateY(0);
    }
  }

  @keyframes uk-slide-left-medium {
    0% {
      transform: translateX(-50px);
    }

    100% {
      transform: translateX(0);
    }
  }

  @keyframes uk-slide-right-medium {
    0% {
      transform: translateX(50px);
    }

    100% {
      transform: translateX(0);
    }
  }

  /*
 * Kenburns
 */
  @keyframes uk-kenburns {
    0% {
      transform: scale(1);
    }

    100% {
      transform: scale(1.2);
    }
  }

  /*
 * Shake
 */
  @keyframes uk-shake {

    0%,
    100% {
      transform: translateX(0);
    }

    10% {
      transform: translateX(-9px);
    }

    20% {
      transform: translateX(8px);
    }

    30% {
      transform: translateX(-7px);
    }

    40% {
      transform: translateX(6px);
    }

    50% {
      transform: translateX(-5px);
    }

    60% {
      transform: translateX(4px);
    }

    70% {
      transform: translateX(-3px);
    }

    80% {
      transform: translateX(2px);
    }

    90% {
      transform: translateX(-1px);
    }
  }

  /*
 * Stroke
 */
  @keyframes uk-stroke {
    0% {
      stroke-dashoffset: var(--uk-animation-stroke);
    }

    100% {
      stroke-dashoffset: 0;
    }
  }
</style>

<body>
  <!-- <header>

</header> -->
  <nav class="uk-animation-slide-top">
    <ul class="ul">
      <li class="li" style="margin-left: 50px;"><a class="a disabled" href="<?php echo site_url('masyarakat/dashboard') ?>">Dashboard</a></li>
      <li class="li item" style="width: 200px;">
        <div class="a dropdown">
          <button class=" btn dropdown-toggle" style="background: #02231c;color: white;height: 8vh;" type="button" data-toggle="dropdown">Kontak
            <span class="caret"></span>
          </button>
          <ul class="dropdown-menu" style="width: 500px;margin-top: 2px;">
            <li><a class="drop-items" href=""><i class="icon-drop bx bxl-facebook" style="min-width: 50px;"></i> Facebook</a></li>
            <li><a class="drop-items" href=""><i class="icon-drop bx bxl-twitter" style="min-width: 50px;"></i> Twitter</a></li>
            <li><a class="drop-items" href=""><i class="icon-drop bx bxl-google" style="min-width: 50px;"></i> Google</a></li>
            <li><a class="drop-items" href=""><i class="icon-drop bx bxl-instagram" style="min-width: 50px;"></i> Instagram</a></li>
            <li><a class="drop-items" href=""><i class="icon-drop bx bxl-github" style="min-width: 50px;"></i> Github</a></li>
          </ul>
        </div>
      </li>
      <li class="li item"><a class="a" href="#">Tentang</a></li>
      <li class="menu2"><i class="btn-menu bx bx-menu"></i></li>
    </ul>
    <div class="item-nav ">
      <div class="">
        <ul class="display-mini uk-animation-slide-right uk-animation-slide-left">
          <li class="li-items-dropdown dropdown1 center red">
            <button class="btn dropdown-toggle li-items-dropdown dropdown1 button" style="color: white;height: 8vh;" type="button" data-toggle="dropdown">
              <i class="icon bx bx-support"></i><a class="link" style="width: 100%;text-align: start;">Kontak</a>
            </button>
            <div class="position">
              <div class="dropdown-menu uk-animation-slide-right" style="padding: 0px;">
                <a class="drop-items" href=""><i class="icon-drop bx bxl-facebook"></i> Facebook</a>
                <a class="drop-items" href=""><i class="icon-drop bx bxl-twitter"></i> Twitter</a>
                <a class="drop-items" href=""><i class="icon-drop bx bxl-google"></i> Google</a>
                <a class="drop-items" href=""><i class="icon-drop bx bxl-instagram"></i> Instagram</a>
                <a class="drop-items" href=""><i class="icon-drop bx bxl-github"></i> Github</a>
              </div>
            </div>
          </li>
          <div class="drop-bottom">
            <li class="li-items">
              <div class="position"><i class="icon bx bx-info-circle"></i><a class="link" href="">Tentang</a></div>
            </li>
            <li class="li-items">
              <div class="position"><i class="icon bx bxs-file-plus"></i><a class="link" href="<?php echo site_url('masyarakat/pengaduan') ?>">Tambah Laporan</a></div>
            </li>
            <li class="li-items">
              <div class="position"><i class="icon bx bxs-report"></i><a class="link" href="<?php echo site_url('masyarakat/laporan') ?>">Laporan</a></div>
            </li>
            <li class="li-items">
              <div class="position"><i class="icon bx bx-cog"> </i><a class="link" href="">Pengaturan</a> </div>
            </li>
            <li class="profile">
              <div class="position"><i class="icon-profile bx bx-user"> </i><a onclick="return confirm('Keluar?')" class="link" style="color: white;width: 500px;"><?= $_SESSION['username'] ?></a><i class="icon left-auto bx bx-log-out"></i></div>
            </li>
        </ul>

        </ul>
      </div>
    </div>
  </nav>
  <div class="div">

    <aside class="">
      <ul class="display">
        <li class="li-button menu1">
          <div class=""><a href="#"> <i class="cursor bx bx-menu"> </i> </a> </div>
        </li>
        <li class="li-items" style="margin-top: 20px;">

          <a href="<?php echo site_url('masyarakat/pengaduan') ?>">
            <div class="position"><i class="icon bx bxs-file-plus"> </i><a class="link" href="<?php echo site_url('masyarakat/pengaduan') ?>">Tambah Laporan </a></div>
          </a>

        </li>
        <li class="li-items">

          <a href="<?php echo site_url('masyarakat/laporan') ?>">
            <div class="position"><i class="icon bx bxs-report"> </i><a class="link" href="<?php echo site_url('masyarakat/laporan') ?>">Laporan </a> </div>
          </a>

        </li>
        <li class="li-items">

          <a href="<?php echo site_url('masyarakat/settings') ?>">
            <div class="position"><i class="icon bx bx-cog"> </i><a class="link" href="<?php echo site_url('masyarakat/settings') ?>">Pengaturan </a> </div>
          </a>

        </li>
      </ul>
      <ul class="bottom">
        <li class="profile">

          <a href="<?php echo site_url('auth_masyarakat/logout') ?>">
            <div class="position"><i class="icon-profile bx bx-user"> </i><a onclick="return confirm('Keluar?')" class="link" href="<?php echo site_url('auth_masyarakat/logout') ?>" style="min-width: 90px;line-height: 50px;"><?= $_SESSION['username'] ?></a><i class="log bx bx-log-out"></i></div>
          </a>

        </li>
      </ul>
    </aside>

    <main style="display: block;">

      <div class="container table-responsive" style="margin-top: 100px; margin-right:50px; max-width: 75%;margin-left: auto;margin-bottom: 100px;">
        <!-- <div class="border" style="border-radius: 5px;"> -->
        <table class="table" id="datatable">
          <h1 class="text-center" style="margin-bottom: 50px;font-family: 'Roboto', sans-serif;font-weight: 500;">Tabel Data Tanggapan</h1>
          <div style="font-family: 'Montserrat', sans-serif;">
            <thead style="font-family: 'Montserrat', sans-serif;font-weight: 400;">
              <tr>
                <th class="border">*</th>
                <th class="border">Tanggal Pengaduan</th>
                <th class="border">Tanggal Tanggapan</th>
                <th class="border">Isi Laporan</th>
                <th class="border">Tanggapan</th>
                <th class="border">Foto</th>
                <th class="border" style="width: 200px;">Status</th>
              </tr>
            </thead>
            <tbody style="font-family: 'Montserrat', sans-serif;font-weight: 400;">
              <?php foreach ($pengaduan as $data) : ?>
                <tr>
                  <td class="border"><?= $data['level'] ?> <?= $data['nama_petugas'] ?></td>
                  <td class="border"><?= $data['tgl_pengaduan'] ?></td>
                  <td class="border"><?= $data['tgl_tanggapan'] ?></td>
                  <td class="border"><?= $data['isi_laporan'] ?></td>
                  <td class="border"><?= $data['tanggapan'] ?></td>
                  <td class="border">
                    <button type="button" class="btn border-0 p-0 m-0" style="border: none;outline: 0 !important;border-radius: 0px;" data-toggle="modal" data-target="#exampleModalLong<?= $data['id_pengaduan'] ?>">
                      <img width="80px" src="<?= base_url() . "uploads/" . $data['foto'] ?>" alt="" srcset="">
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModalLong<?= $data['id_pengaduan'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true" style="margin-top: 9vh;">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            Close
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body" style="display: contents;width: auto;">
                            <img src="<?= base_url() . "uploads/" . $data['foto'] ?>" alt="" srcset="">
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td class="border" style="width: 200px;"><?= $data['status'] ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
        </table>
        <!-- </div> -->
      </div>
  </div>
  </main>

  </div>
  <footer>

  </footer>
  <script src="https://cdn.jsdelivr.net/npm/uikit@3.15.24/dist/js/uikit.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#datatable').DataTable({});
    });
  </script>
</body>

</html>
<script>
  side = document.querySelector('aside'),
    menuBtns = document.querySelector(".menu1");
  menuBtns.addEventListener("click", () => {
    side.classList.toggle("mini");
  })
  nav = document.querySelector(".item-nav"),
    menuBtn = document.querySelector(".menu2");
  menuBtn.addEventListener("click", () => {
    nav.classList.toggle("open");
  })
</script>
<!-- at the end of the body -->
<script type="text/javascript" src="vanilla-tilt.js"></script>