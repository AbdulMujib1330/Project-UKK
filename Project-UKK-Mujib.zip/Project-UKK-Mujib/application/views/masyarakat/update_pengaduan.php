<!DOCTYPE html>
<html lang="en" style="height: 100vh;">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="icon" type="image/png" href="../img/icon.png"/>
  <title>Perbaiki Pengaduan</title>
</head>
<style>
  * {
    margin: 0;
    padding: 0;
  }

  html {
    height: 100vh;
  }

  body {
    height: auto;
    width: auto;
    background: -webkit-linear-gradient(bottom, #ffffff, #a6f77b);
    background-repeat: no-repeat;
  }

  .font {
    font-family: Arial, Helvetica, sans-serif;
  }

  .card {
    background-color: white;
  }

  .button {
    border: white 1px;
    border-radius: 25px;
    color: white;
    height: 40px;
    width: 50%;
    background: -webkit-linear-gradient(top, #a6f77b, #2ec06f);
    box-shadow: 0px 1px 8px #24c64f;
  }

  .line {
    background: -webkit-linear-gradient(bottom, #a6f77b, #2ec06f);
    height: 5px;
    border-radius: 5px;
    width: 80%;
  }

  .card-me {
    border-radius: 10px;
    box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
    background-color: white;
    padding-top: 20px;
    padding-right: 45px;
    padding-left: 45px;
  }
  .text-center{
    margin-bottom: 20px;
  }

  @media screen and (max-width : 500px) {
    .card-me {
      width: 100%;
    }
  }

  @media screen and (min-width : 500px) {
    .card-me {
      width: 600px;
    }
  }

  @media screen and (max-height : 600px) {
    .card-me {
      height: 100%;
      border-radius: 0;
    }

    .margin {
      margin: 0px;
    }

    .padding {
      padding-bottom: 0px;
    }

    .textarea {
      height: 150px;
      margin-bottom: 5px;
    }

    .button {
      width: 150px;
    }
    
  .text-center{
    margin-bottom: 0;
  }
  }

  @media screen and (min-height : 700px) {
    .textarea {
      height: 100%;
      margin-bottom: 5px;
    }
  }
</style>

<body class="d-flex" style="font-family: Arial, Helvetica, sans-serif;">
  <div class="d-flex form-floating" id="card">
    <div class="mx-auto" id="card-content">
      <div class="card d-flex card-me" style="position: fixed;top: 50%;left: 50%;transform: translate(-50%, -50%);">
        <div class="card-header mt-1 px-100 border-bottom-0" style="background-color: white;padding-top: 30px;">
          <div class="text-center" id="card-title">
            <h2 class="m-0" style="font-weight: bold;">Memperbarui Pengaduan</h2>
          </div>
        </div>
        <center>
          <div class="line"></div>
        </center>
        <div class="card-body padding">
          <form action="<?php echo site_url('auth_masyarakat/update_pengaduan/' . $data['id_pengaduan']) ?>" method="post" enctype="multipart/form-data" class="form">
            <div class="text-center">
              <span>Nik Anda</span>
              <div class="rounded" style="border:#dee2e6 solid 1px;background-color:#fff;">
                <?= $_SESSION['nik'] ?>
              </div>
            </div>

            <div class="form-group text-center">
              <label for="comment">Memperbarui Pengaduan Anda</label>
              <textarea class="textarea form-control" name="isi_laporan" rows="10" id="comment" type="text"><?= $data['isi_laporan'] ?></textarea>
            </div>

            <div class="" style="text-align: center;">
              <input class="form-control" name="foto" type="file" id="formFile">
            </div>

            <div class="text-center margin mb-3">
              <input type="text" id="auto_date" style="margin-top: auto;display:none;" readonly value="" name="tgl_pengaduan" class="form-control text-center">
            </div>
        </div>

        <div class="row">
          <center>
            <div class="col-lg-12 mx-auto">
              <button class="button px-5">Kirim</button>
            </div>
          </center>
          <center>
            <div class="col-lg-12 mx-auto">
              <a onclick="return confirm('Ingin Keluar?')" href="<?= base_url('masyarakat/laporan') ?>" style="text-decoration: none;color: #2dbd6e;" id="back">Kembali </a></p>
            </div>
          </center>
        </div>

        </form>
      </div>
    </div>
  </div>
  </div>

</body>

</html>
<script>
  var date = new Date();
  var current_date = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
  document.getElementById("auto_date").value = current_date;
</script>
<script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>