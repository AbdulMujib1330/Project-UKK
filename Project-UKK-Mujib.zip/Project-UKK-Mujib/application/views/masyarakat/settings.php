<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tilt+Neon&display=swap" rel="stylesheet">
    <title>Pengaturan</title>
</head>

<body class="d-flex h-100 w-100" style="font-family: 'Tilt Neon', cursive;">
    <!-- <a class="btn btn-primary rounded-0 w-100" style="font-family: Arial, Helvetica, sans-serif;" href="<?php echo site_url('masyarakat/laporan') ?>">Back</a> -->
    <div class="profile text-center mx-auto" style="top: 50%;left: 50%;transform: translate(-50%, -50%);" data-tilt>
        <div class="card">
            <center>
                <i class='bx bx-user' style="font-size: 500px;"></i>
            </center>
            <div class="name">
                Hallo <?= $_SESSION['nama'] ?>
            </div>
            <a class="btn btn-primary rounded-0 w-100" style="font-family: Arial, Helvetica, sans-serif;" href="<?php echo site_url('masyarakat/laporan') ?>">Back</a>
        </div>
    </div>
    <!-- <?= $_SESSION['nik'] ?>
    <?= $_SESSION['username'] ?>
    <?= $_SESSION['password'] ?>
    <?= $_SESSION['telp'] ?> -->

    <script type="text/javascript" src="<?php echo base_url(); ?>/js/vanilla-tilt.js"></script>
    <script type="text/javascript">
        VanillaTilt.init(document.querySelector(".profile"), {
            max: 25,
            speed: 400
        });
        //It also supports NodeList
        VanillaTilt.init(document.querySelectorAll(".name"));
    </script>
</body>

</html>