<!DOCTYPE html>
<html lang="en" style="height: 100vh;">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <!-- <script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> -->
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script> -->
  <link rel="icon" type="image/png" href="../img/icon.png"/>
  <title>Tanggapan</title>
</head>
<style>
  * {
    margin: 0;
    padding: 0;
  }

  html {
    height: 100vh;
  }

  body {
    height: auto;
    width: auto;
    background: -webkit-linear-gradient(bottom, #ffffff, #a6f77b);
    background-repeat: no-repeat;
  }

  .card-my {
    border-radius: 10px;
    box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
    background-color: white;
    padding-top: 40px;
    padding-right: 48px;
    padding-left: 48px;
  }

  .card {
    width: 600px;
  }


  .textarea-content {
    height: 80px;
    margin-bottom: 5px;
  }

  .form-control {
    height: auto;
    /* margin-bottom: 5px; */
  }

  .textarea {
    height: 120px;
    /* margin-bottom: 5px; */
  }

  .textarea-foto {
    height: 120px;
    /* margin-bottom: 5px; */
  }

  .bottom {
    margin-bottom: 8px;
  }

  .line {
    background: -webkit-linear-gradient(bottom, #a6f77b, #2ec06f);
    height: 5px;
    border-radius: 5px;
    width: 70%;
  }


  .button {
    border: white 1px;
    border-radius: 25px;
    color: white;
    height: 40px;
    width: 50%;
    background: -webkit-linear-gradient(top, #a6f77b, #2ec06f);
    box-shadow: 0px 1px 8px #24c64f;
  }


  .modal-backdrop {
    z-index: 0;
    opacity: 0;
  }

  .modal-backdrop.show {
    opacity: 0;
    z-index: 0;
    display: none;
  }

  @media screen and (max-height : 550px) {
    .tanggal-pengaduan {
      display: none;
    }
  }

  @media screen and (max-width : 700px) {

    /* .size {
      height: 100%;
    } */
    .card-my {
      border-radius: 0;
      padding-top: 5px;
      padding-right: 0;
      padding-left: 0;
    }
    .textarea-foto {
      margin-bottom: 0;
      height: auto;
    }

    .card {
      height: 100%;
      width: 100%;
    }

    .margin {
      margin: 0px;
    }

    .padding {
      padding-bottom: 0px;
    }

    .textarea {
      height: 50px;
      margin-bottom: 5px;
    }

    .textarea-content {
      height: 50px;
      margin-bottom: 5px;
    }

    .button {
      width: 80%;
    }
  }

  /* @media screen and (min-height : 700px) {
    .textarea {
      height: 100%;
      margin-bottom: 5px;
    } */
</style>

<body class="d-flex" style="font-family: Arial, Helvetica, sans-serif;">
  <!-- <div class="underline-title"></div> -->
  <div class="form-floating" id="card">
    <div class="mx-auto" id="card-content">
      <div class="card size card-my" style="position: fixed;top: 50%;left: 50%;transform: translate(-50%, -50%);">
        <div class="card-header border-bottom-0 mt-1 px-100" style="background-color: white;">
          <div class="text-center" id="card-title">
            <h2 class="m-0" style="font-weight: bold;">Tanggapan</h2>
            <center>
              <div class="line"></div>
            </center>
          </div>
        </div>
        <div class="card-body padding">
          <form action="<?php echo site_url('auth_petugas/tanggapan/' . $data['id_pengaduan']) ?>" method="post" enctype="multipart/form-data" class="form">


            <div class="row border-bottom">
              <div class="col-12 bottom">
                <div class="form-group text-center row">
                  <div class="col-md-6 col-sm-12">
                    <label for="laporan">Laporan Pengaduan</label>
                    <p class="textarea form-control" rows="10" id="laporan" type="text"><?= $data['isi_laporan'] ?></p>
                  </div>
                  <div class="col-md-6 col-sm-12">
                    <label for="foto">Foto</label>
                    <p class="textarea-foto form-control" rows="10" id="foto" type="text">
                      <button type="button" class="btn border-0 p-0 m-0" style="border: none;outline: 0 !important;border-radius: 0px;" data-toggle="modal" data-target="#exampleModalLong<?= $data['id_pengaduan'] ?>">
                        <img width="80px" src="<?= base_url() . "uploads/" . $data['foto'] ?>" alt="" srcset="">
                      </button>
                    </p>
                  </div>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModalLong<?= $data['id_pengaduan'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true" style="margin-top: 9vh;">
                    <div class="modal-dialog modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          Close
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body" style="display: contents;width: auto;">
                          <img sizes="auto" src="<?= base_url() . "uploads/" . $data['foto'] ?>" alt="" srcset="">
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- <textarea class="form-control" rows="10" id="comment"></textarea> -->
                </div>
              </div>
              <div class="col-12 text-center tanggal-pengaduan">
                <label for="tgl_pengaduan">Tanggal Pengaduan</label>
                <input type="text" readonly for="tgl_pengaduan" value="<?= $data['tgl_pengaduan'] ?>" name="tgl_pengaduan" class="form-control text-center">
              </div>
            </div>



            <div class="form-group text-center">
              <label for="comment">Tanggapan</label>
              <textarea class="textarea-content form-control" style="height: 80px;" name="tanggapan" rows="10" id="comment" type="text"></textarea>
              <!-- <textarea class="form-control" rows="10" id="comment"></textarea> -->
            </div>
            <!-- <div class="form-floating input-group mb-5">
          <div class="input-group-prepend">
            <input type="text" class="form-control input-group-text" style="padding-bottom: 200px;" id="floatingPassword" placeholder="complaint">
            <textarea class="form-control" aria-label="With textarea"></textarea>
          </div>
          </div> -->


            <!-- <div class="">
              <label for="formFile" class="form-label">Default file input example</label>
              <input class="form-control" name="foto" type="file" id="formFile">
            </div> -->

            <!-- <div class="mb-3">
            <input type="text" class="form-control" id="auto_date">
            <label id="auto_date"></label>
            <label for="floatingInput">Date</label>
          </div> -->

            <div class="text-center margin mb-3" style="display: none;">
              <input type="text" id="auto_date" readonly value="" name="tgl_tanggapan" class="form-control text-center">
            </div>
            <!-- <label for="floatingInput"></label> -->
            <div class="row">
              <center>
                <div class="col-lg-12 mx-auto">
                  <button class="button px-5">Kirim</button>
                </div>
              </center>
              <center>
                <div class="col-lg-12 mx-auto">
                  <a onclick="return confirm('Ingin Keluar?')" href="<?= base_url('petugas/laporan') ?>" style="text-decoration: none;color: #2dbd6e;" id="back"> Back</a></p>
                </div>
              </center>
            </div>
        </div>


        </form>
      </div>
    </div>
  </div>
  </div>
</body>

</html>
<script>
  var date = new Date();
  var current_date = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
  document.getElementById("auto_date").value = current_date;
</script>