<?php
defined('BASEPATH') or exit('No direct script access allowed');

class auth_petugas extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('petugas_auth');
        $this->load->model('masyarakat_auth');
        $this->load->model('petugas_login');
    }

    public function register()
    {
        $this->load->view('petugas/register');
        $nama_petugas   = $this->input->post('nama_petugas');
        $username         = $this->input->post('username');
        $password         = $this->input->post('password');
        $telp             = $this->input->post('telp');

        $query = $this->petugas_auth->insert($nama_petugas, $username, $password, $telp);
        if ($query) {
            redirect('petugas/login');
        }
    }

    public function login()
    {
        $nama_petugas    = $this->input->post('nama_petugas');
        $password = $this->input->post('password');

        $this->petugas_login->ambillogin($nama_petugas, $password);
    }

    public function tanggapan($id_pengaduan)
    {
        $proses = array(
            'id_pengaduan' =>$id_pengaduan,
			'status' => 'selesai',
		);
        $update = $this->petugas_auth->update_pengaduan('pengaduan',$proses);
            $id_petugas = $_SESSION['id_petugas'];
            $data = array(
                'id_pengaduan' => $id_pengaduan,
                'tgl_tanggapan' => $this->input->post('tgl_tanggapan'),
                'tanggapan' => $this->input->post('tanggapan'), 
                'id_petugas' => $id_petugas,
            );
    
            $query = $this->petugas_auth->tanggapan($data);
            if ($query) {
                redirect('petugas/laporan');
            }
            redirect('petugas/laporan');
    }
    
	public function delete_tanggapan($id_tanggapan)
	{
		$this->load->model('petugas_auth');
		// $query = $this->petugas_auth->update_pengaduan();
		$query = $this->petugas_auth->tanggapan_delete($id_tanggapan);
		redirect('petugas/laporan_tanggapan');
	}

    public function logout()
    {
        // $this->session->set_userdata('username',FALSE);
        $this->session->unset_userdata('nama_petugas');
        redirect('petugas/login');
    }
}
