<?php
defined('BASEPATH') or exit('No direct script access allowed');

class auth_masyarakat extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('masyarakat_auth');
		$this->load->model('masyarakat_login');
	}

	// SEMENTARA
	function sidebar()
	{
		$this->load->view('sidebar/sidebar2');
	}

	public function home()
	{
		$this->load->view('home');
	}

	public function pengaduan()
	{

		// id_pengaduan	tgl_pengaduan	nik	isi_laporan	foto	status	
		$tgl_pengaduan 	= $this->input->post('tgl_pengaduan');
		$nik 			= $_SESSION['nik'];
		$isi_laporan 	= $this->input->post('isi_laporan');
		// $foto 			= $this->input->post('foto');
		$foto 			= $_FILES['foto'];
		// $pengaduan_length = count($this->db->get('pengaduan')->result());
		// $id_pengaduan = 1;
		// $id_pengaduan = $nilai1 + 1;
		// $nilai1 = $nilai1 + $id_pengaduan;
		// $id_pengaduan = $nilai1 + 1;
		// $nilai1 = $nilai1 + $id_pengaduan;
		// $id_pengaduan = $nilai1 + 1;
		// $nilai1 = $nilai1 + $id_pengaduan;
		// $id_pengaduan = $nilai1 + 1;
		// var_dump($id_pengaduan);
		// if ($pengaduan_length > 0) {
		// $id_pengaduan = $this->db->get('pengaduan')->result()[$pengaduan_length - 1]->id_pengaduan;
		// 	var_dump($id_pengaduan);
		// }
		$pengaduan_length = count($this->db->get('pengaduan')->result());
		$id_pengaduan = 1;

		if ($pengaduan_length > 0) {
			$id_pengaduan = $this->db->get('pengaduan')->result()[$pengaduan_length - 1]->id_pengaduan;
			var_dump($id_pengaduan);
		}

		if ($pengaduan_length > 0) {
			$id_pengaduan = $this->db->get('pengaduan')->result()[$pengaduan_length - 1]->id_pengaduan;
		
			// Jika $id_pengaduan lebih besar dari 0, increment nilai $id_pengaduan
			if ($id_pengaduan > 0) {
				$id_pengaduan++;
			}
		} else {
			// Jika $id_pengaduan kosong (NULL atau empty), isi dengan nilai 1
			$id_pengaduan = 1;
		}
		
		if ($foto = '') {
		} else {
			var_dump(is_dir('./uploads/'));
			// TES
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'jpg|png';
			$config['file_name'] = $id_pengaduan;
			$config['overwrite'] = true;
			$config['max_size'] = 0;
			$config['max_width'] = 0;
			$config['max_height'] = 0;
			$config['encrypt_name'] = FALSE;

			var_dump($config);
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload('foto')) {

				echo "yes";
			} else {
				// exit;
				echo 	"<script>alert('Haya Bisa Menggunakan File JPG');</script>";
				redirect('masyarakat/pengaduan');
			}
		}
		$query = $this->masyarakat_auth->pengaduan($tgl_pengaduan, $nik, $isi_laporan, $this->upload->data()['file_name']);
		if ($query) {
			redirect('masyarakat/laporan');
		}
	}
	public function update_pengaduan($id_pengaduan)
	{

		$foto 				= $_FILES['foto'];

		if ($foto = '') {
		} else {
			var_dump(is_dir('./uploads/'));
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'jpg|png';
			$config['file_name'] = $id_pengaduan;
			$config['overwrite'] = true;
			$config['max_size'] = 0;
			$config['max_width'] = 0;
			$config['max_height'] = 0;
			$config['encrypt_name'] = FALSE;
			// $config['image_type']

			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload('foto')) {
				echo "yes";
			} else {
				redirect('masyarakat/update/' . $id_pengaduan);
			}
		}
		$nik = $_SESSION['nik'];
		$tgl_pengaduan = $this->input->post('tgl_pengaduan');
		$isi_laporan = $this->input->post('isi_laporan');



		$query = $this->masyarakat_auth->update($id_pengaduan, $tgl_pengaduan, $nik, $isi_laporan, $this->upload->data()['file_name']);
		redirect('masyarakat/laporan');
	}

	public function delete($id_pengaduan)
	{
		$this->load->model('masyarakat_auth');
		$png = '.png';
		$jpg = '.jpg';
		$query = $this->masyarakat_auth->delete($id_pengaduan);
		if ($query > 0) {
			// $file = $this->load->helper($this->upload->data()['file_name']);
			// unlink('imgproduk/' . $produk['gambar']);
			//  unlink($_SERVER['DOCUMENT_ROOT'].'/imgproduk/' . $produk['gambar']);
			unlink('./uploads/' . $id_pengaduan . $png);
			unlink('./uploads/' . $id_pengaduan . $jpg);
			$this->db->query('ALTER TABLE pengaduan AUTO_INCREMENT = 0');
		} else {
			if (count($this->db->get('pengaduan')->result()) <= 0) {
				$this->db->query('ALTER TABLE pengaduan AUTO_INCREMENT = 0');
			}
			redirect('masyarakat/laporan');
		}
		redirect('masyarakat/laporan');
	}

	public function register()
	{
		$this->load->view('masyarakat/register');
		$nik 		= $this->input->post('nik');
		$nama 		= $this->input->post('nama');
		$username 	= $this->input->post('username');
		$password 	= $this->input->post('password');
		$telp 		= $this->input->post('telp');
		// $data['username'] = $username;
		// $data['nama'] = $nama;
		// $data['password'] = $password;
		// $data['telp'] = $telp;
		$cek = $this->masyarakat_auth->get_data($nik);

		if (count($cek) <= 0) {
			$query = $this->masyarakat_auth->insert($nik, $nama, $username, $password, $telp);
			if ($query) {
				// var_dump($cek);
				redirect('masyarakat/login');
			}
			// else{
			// 	redirect('masyarakat/register');
			// }

		} else {
			// echo "Data salah";
			echo '<script> alert("Duplicate Data") ; </script>';
		}
	}

	public function login()
	{
		$nama = $this->input->post('nama');
		$password = $this->input->post('password');

		// $this->load->model('masyarakat_login');
		$this->masyarakat_login->ambillogin($nama, $password);
	}

	public function logout()
	{
		// $this->session->set_userdata('username',FALSE);
		$this->session->unset_userdata('nama');
		redirect('');
	}
}


	
	
				// redirect('masyarakat/register');
	
			// $data = [
			// 	'nik' => $this->input->post('nik'),
			// 	'nama' => $this->input->post('nama'),
			// 	'username' => $this->input->post('username'),
			//     'password' => $this->input->post('password'),
			//     'telp' => $this->input->post('telp'),
			// ];
	
			// $query = $this->db->insert('masyarakat', $data);
			// $this->load->model('masyarakat_auth');
	// var_dump($username);
	// var_dump($password);

	// $this->session->set_userdata($nama);
	// 	$data =array(
	//         'author_name'  => 'Sajal Soni',
	//         'website'     => 'http://code.tutsplus.com',
	//         'twitter_id' => '@sajalsoni',
	//         'interests' => array('tennis', 'travelling')
	// );
	// echo '<pre>';
	// print_r($this->session->userdata());
	// isset($_SESSION['name'])