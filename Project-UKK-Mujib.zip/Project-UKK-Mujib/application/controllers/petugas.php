<?php
defined('BASEPATH') or exit('No direct script access allowed');

class petugas extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('petugas_login');
	}

	public function login()
	{
		$this->load->view('petugas/login');
		$this->petugas_login->cek_login();
	}

	public function register()
	{
		$this->load->view('petugas/register');
		$this->petugas_login->cek_login();
	}

	public function laporan()
	{
		$pengaduan['pengaduan'] = $this->db->get('pengaduan')->result_array();
		$this->load->view('petugas/laporan', $pengaduan);
		$this->petugas_login->cek_session();
	}
	public function tanggapan($id_pengaduan)
	{
		$this->db->where('id_pengaduan', $id_pengaduan);
		$datas['data'] = $this->db->get('pengaduan')->row_array();

		$this->load->view('petugas/tanggapan', $datas);
		$this->petugas_login->cek_session();
	}
	public function laporan_tanggapan()
	{// <-- There is never any reason to write this line!
		$this->db->join('tanggapan', 'petugas.id_petugas = tanggapan.id_petugas');
		$this->db->join('pengaduan','tanggapan.id_pengaduan = pengaduan.id_pengaduan');
		// $this->db->get('petugas');
		$data['datas'] = $this->db->get('petugas')->result_array();

		$this->load->view('petugas/laporan_tanggapan', $data);
		$this->petugas_login->cek_session();
	}
}
