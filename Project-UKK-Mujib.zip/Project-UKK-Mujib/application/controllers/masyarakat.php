<?php
defined('BASEPATH') or exit('No direct script access allowed');

class masyarakat extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('masyarakat_login');
	}

	public function login()
	{
		$this->load->view('masyarakat/login');
		$this->masyarakat_login->cek_login();
	}

	public function register()
	{
		$this->load->view('masyarakat/register');
		$this->masyarakat_login->cek_login();
	}

	public function laporan()
	{
		// $this->db->select('title, content, date');
		// $this->db->from('mytable');
		// $query = $this->db->get();
		$nik = $_SESSION['nik'];
		$this->db->where('nik', $nik);
		$pengaduan['pengaduan'] = $this->db->get('pengaduan')->result_array();
		$this->load->view('masyarakat/laporan', $pengaduan);
		$this->masyarakat_login->cek_session();
		// die();
		// var_dump($pengaduan);
		// echo $pengaduan;
		// $this->sidebar('laporan');
		// $this->load->view('sidebar/sidebar2');
		// $this->session->set_userdata($_SESSION['nik']);
		// $nik = $_SESSION['nik'];
	}

	public function pengaduan()
	{
		$this->load->view('masyarakat/pengaduan');
		$this->masyarakat_login->cek_session();
	}
	public function update($id_pengaduan)
	{

		$this->db->where('id_pengaduan', $id_pengaduan);
		$datas['data'] = $this->db->get('pengaduan')->row_array();

		$this->load->view('masyarakat/update_pengaduan', $datas);
		$this->masyarakat_login->cek_session();
	}

	public function tanggapan()
	{

		// $this->db->join('tanggapan', 'petugas.id_petugas = tanggapan.id_petugas');
		// $this->db->join('pengaduan','tanggapan.id_pengaduan = pengaduan.id_pengaduan');
		// $this->db->from('masyarakat');
		// $petugas = $this->db->query('select * from petugas;')->result_array();
		// $pengaduans = $query->result();
		// foreach ($pengaduans as $data){
		// 	echo $data->petugas . $data->nama_petugas;
		// }
		// var_dump($pengaduan['nama_petugas']);
		$query =$this->db->query('SHOW TABLES');
		$tables = $query->row_array();
		
		foreach ($tables as $data){
			echo $data->petugas['nama_petugas'];
		}
		// var_dump($tables);
		$nik = $_SESSION['nik'];
		$this->db->where('nik', $nik);
		$pengaduan['pengaduan'] = $this->db->get('pengaduan')->result_array();
		// $this->load->view('masyarakat/tanggapan', $pengaduan);
		$this->masyarakat_login->cek_session();
	}
	public function dashboard()
	{

		$nik = $_SESSION['nik'];
		$this->db->where('nik', $nik);
		$pengaduan['pengaduan'] = $this->db->get('pengaduan')->result_array();
		$this->load->view('masyarakat/dashboard', $pengaduan);
		$this->masyarakat_login->cek_session();
	}
	public function settings()
	{
		$this->load->view('masyarakat/settings');
		$this->masyarakat_login->cek_session();
	}

	// public function sidebar()
	// {
	// 	$this->load->view('sidebar/sidebar');
	// }

}
