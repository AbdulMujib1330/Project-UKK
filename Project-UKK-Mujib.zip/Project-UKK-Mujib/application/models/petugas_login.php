<?php
defined('BASEPATH') or exit('No direct script access allowed');

class petugas_login extends CI_Model
{
    public function ambillogin($nama_petugas, $password)
    {
        $this->db->where('nama_petugas', $nama_petugas);
        $this->db->where('password', $password);
        $query = $this->db->get('petugas');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $sess_petugas = array(
                    'id_petugas' => $row->id_petugas,
                    'nama_petugas' => $row->nama_petugas,
                    'username' => $row->username,
                    'password' => $row->password,
                    'telp' => $row->telp,
                    'level' => $row->level,
                );
            }
            $this->session->set_userdata($sess_petugas);

            redirect('petugas/laporan');
        } else {
            $this->session->set_flashdata('info', 'Maaf Data Yang Anda Masukkan Salah');
            redirect('petugas/login');
        }
        // die();
        // var_dump($sess);

    }

    public function cek_session()
    {
        if (!isset($_SESSION['nama_petugas'])) {
            redirect('petugas/login');
        }
    }

    public function cek_login()
    {
        if (isset($_SESSION['nama_petugas'])) {
            redirect('petugas/laporan');
        }
    }
}
