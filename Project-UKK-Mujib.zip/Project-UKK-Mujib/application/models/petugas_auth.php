<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class petugas_auth extends CI_Model {
    public function insert($nama_petugas,$username,$password,$telp)
    {
        return  $this->db->insert('petugas', array('nama_petugas'=> $nama_petugas,'username'=> $username,'password'=> $password,'telp'=> $telp,'level'=> 'admin'));
    }
    public function tanggapan($data)
    {
        return  $this->db->insert('tanggapan',$data);
    }
    public function tanggapan_delete($id_tanggapan)
    {
        return $this->db->delete('tanggapan', array('id_tanggapan' => $id_tanggapan));
    }
    public function update_pengaduan($id_pengaduan,$data_masyarakat)
    {
        $id_pengaduan = $this->db->where('id_pengaduan', $data_masyarakat['id_pengaduan']); 
        $this->db->update('pengaduan', $data_masyarakat);
    }
}
?>