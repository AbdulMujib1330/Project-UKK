<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class code extends CI_Controller {
    
	public function home()
	{
		$this->load->view('home');
	}
	public function login()
	{
		$this->load->view('petugas/login');
	}
}
