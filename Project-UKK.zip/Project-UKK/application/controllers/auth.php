<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class auth extends CI_Controller {
    
	public function login()
	{
		$this->load->view('masyarakat/login');
	}

	public function register()
	{
		$this->load->view('masyarakat/register');
	}

    public function insert($username,$password)
    {
        $this->load->view('masyarakat/register');

		$data['username'] = $username;
		$data['password'] = $password;

        $data = [
			'nik' => $this->input->post('nik'),
			'nama' => $this->input->post('nama'),
			'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
            'telp' => $this->input->post('telp'),
		];

		$query = $this->db->insert('masyarakat', $data);
		if ($query) {
			redirect('sign_up');
		}
    }
	
	public function log_in()
	{
		// $this->session->set_userdata($nama);
	// 	$data =array(
    //         'author_name'  => 'Sajal Soni',
    //         'website'     => 'http://code.tutsplus.com',
    //         'twitter_id' => '@sajalsoni',
    //         'interests' => array('tennis', 'travelling')
    // );
		// echo '<pre>';
		// print_r($this->session->userdata());
		// isset($_SESSION['name'])
	}
}
